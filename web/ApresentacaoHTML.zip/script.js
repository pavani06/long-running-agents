/* ============================================
   KODA ACADEMY - JAVASCRIPT
   ============================================ */

document.addEventListener('DOMContentLoaded', function() {
    initializeAccordions();
    initializeFilters();
    initializeNavigation();
    initializeScrollAnimations();
});

/* ============================================
   ACCORDION FUNCTIONALITY
   ============================================ */

function initializeAccordions() {
    const accordionHeaders = document.querySelectorAll('.accordion-header');
    
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function(e) {
            e.preventDefault();
            toggleAccordion(this);
        });
    });
}

function toggleAccordion(button) {
    const accordion = button.parentElement;
    const content = accordion.querySelector('.accordion-content');
    const isOpen = button.classList.contains('active');
    
    // Close all other accordions
    document.querySelectorAll('.accordion-header.active').forEach(header => {
        if (header !== button) {
            header.classList.remove('active');
            header.parentElement.querySelector('.accordion-content').classList.remove('open');
        }
    });
    
    // Toggle current accordion
    if (isOpen) {
        button.classList.remove('active');
        content.classList.remove('open');
    } else {
        button.classList.add('active');
        content.classList.add('open');
    }
}

function scrollToLesson(lessonNumber) {
    const accordions = document.querySelectorAll('.accordion');
    if (accordions.length > lessonNumber - 1) {
        accordions[lessonNumber - 1].scrollIntoView({ behavior: 'smooth' });
        // Auto open the accordion
        const header = accordions[lessonNumber - 1].querySelector('.accordion-header');
        if (header && !header.classList.contains('active')) {
            toggleAccordion(header);
        }
    }
}

/* ============================================
   FILTER FUNCTIONALITY
   ============================================ */

function initializeFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const level = this.getAttribute('onclick')?.match(/'([^']+)'/)?.[1] || 'all';
            filterExercises(level);
        });
    });
    
    // Show all exercises by default
    showAllExercises();
}

function filterExercises(level) {
    const cards = document.querySelectorAll('.exercise-card');
    const buttons = document.querySelectorAll('.filter-btn');
    
    // Update active button
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter cards
    cards.forEach(card => {
        card.classList.remove('show');
        if (level === 'all' || card.getAttribute('data-level') === level) {
            card.classList.add('show');
        }
    });
}

function showAllExercises() {
    const cards = document.querySelectorAll('.exercise-card');
    cards.forEach(card => {
        card.classList.add('show');
    });
}

/* ============================================
   NAVIGATION FUNCTIONALITY
   ============================================ */

function initializeNavigation() {
    // Highlight active nav item
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-menu a');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (currentPath.includes(href) && href !== '#') {
            link.classList.add('active');
            // Remove active from other links
            navLinks.forEach(other => {
                if (other !== link) {
                    other.classList.remove('active');
                }
            });
        }
    });
    
    // Add click handlers for smooth navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const element = document.querySelector(href);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
}

/* ============================================
   SCROLL ANIMATIONS
   ============================================ */

function initializeScrollAnimations() {
    if ('IntersectionObserver' in window) {
        const cards = document.querySelectorAll(
            '.level-card, .topic-card, .exercise-card, .case-study-card, .diagram-card'
        );
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });
        
        cards.forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            observer.observe(card);
        });
    }
}

/* ============================================
   UTILITY FUNCTIONS
   ============================================ */

// Smooth scroll to top
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Add smooth scroll behavior
document.addEventListener('click', function(e) {
    const target = e.target.closest('a[href^="#"]');
    if (target && target.href && target.getAttribute('href') !== '#') {
        e.preventDefault();
        const id = target.getAttribute('href').slice(1);
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    }
});

// Handle keyboard navigation
document.addEventListener('keydown', function(e) {
    // Escape key closes open accordions
    if (e.key === 'Escape') {
        document.querySelectorAll('.accordion-header.active').forEach(header => {
            header.classList.remove('active');
            header.parentElement.querySelector('.accordion-content').classList.remove('open');
        });
    }
    
    // Arrow keys navigate between accordions (if one is focused)
    if (document.activeElement?.classList.contains('accordion-header')) {
        const accordions = Array.from(document.querySelectorAll('.accordion'));
        const currentAccordion = document.activeElement.closest('.accordion');
        const currentIndex = accordions.indexOf(currentAccordion);
        
        if (e.key === 'ArrowDown' && currentIndex < accordions.length - 1) {
            e.preventDefault();
            accordions[currentIndex + 1].querySelector('.accordion-header').focus();
        } else if (e.key === 'ArrowUp' && currentIndex > 0) {
            e.preventDefault();
            accordions[currentIndex - 1].querySelector('.accordion-header').focus();
        }
    }
});

/* ============================================
   PROGRESS TRACKING
   ============================================ */

function updateProgress(currentLevel, totalLevels) {
    const progress = (currentLevel / totalLevels) * 100;
    const progressBar = document.querySelector('.progress-fill');
    if (progressBar) {
        progressBar.style.width = progress + '%';
    }
}

/* ============================================
   DETAILS TOGGLE (for case studies)
   ============================================ */

document.addEventListener('click', function(e) {
    if (e.target.tagName === 'SUMMARY') {
        e.target.parentElement.style.marginBottom = 
            e.target.parentElement.open ? '1rem' : '2rem';
    }
});

/* ============================================
   RESPONSIVE MENU TOGGLE
   ============================================ */

function initializeResponsiveMenu() {
    const menu = document.querySelector('.nav-menu');
    if (window.innerWidth <= 768 && menu) {
        // For mobile, you could add hamburger menu logic here
        // This is a placeholder for future enhancement
    }
}

window.addEventListener('resize', initializeResponsiveMenu);

/* ============================================
   PERFORMANCE: LAZY LOADING IMAGES
   ============================================ */

if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.add('loaded');
                observer.unobserve(img);
            }
        });
    });

    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

/* ============================================
   ACCESSIBILITY: FOCUS MANAGEMENT
   ============================================ */

document.addEventListener('keydown', function(e) {
    // Manage focus for interactive elements
    if (e.key === 'Tab') {
        const focusableElements = document.querySelectorAll(
            'a, button, [tabindex], input, select, textarea'
        );
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        if (e.shiftKey) {
            if (document.activeElement === firstElement) {
                lastElement.focus();
                e.preventDefault();
            }
        } else {
            if (document.activeElement === lastElement) {
                firstElement.focus();
                e.preventDefault();
            }
        }
    }
});

/* ============================================
   ANALYTICS HOOKS (for future integration)
   ============================================ */

function trackEvent(eventName, eventData) {
    // Placeholder for analytics integration
    // Example: trackEvent('lesson_completed', { level: 2, lesson: 3 })
    if (typeof gtag !== 'undefined') {
        gtag('event', eventName, eventData);
    } else {
        console.log('Event:', eventName, eventData);
    }
}

// Track page views
function trackPageView(pageName) {
    trackEvent('page_view', { page_path: pageName });
}

/* ============================================
   INITIALIZATION CHECK
   ============================================ */

console.log('KODA Academy - JavaScript initialized');

// Ensure all interactive elements are properly initialized
document.addEventListener('DOMContentLoaded', function() {
    console.log('✓ Accordions initialized');
    console.log('✓ Filters initialized');
    console.log('✓ Navigation initialized');
    console.log('✓ Scroll animations initialized');
    console.log('Ready to learn!');
});
